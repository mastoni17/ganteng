<?php
$db_file = '/var/www/html/web_users.db';
$db = new PDO("sqlite:" . $db_file);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tid = trim($_POST['telegram_id']);
    $pass = $_POST['password'];

    $stmt = $db->prepare("SELECT * FROM web_users WHERE telegram_id = ?");
    $stmt->execute([$tid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($pass, $user['password'])) {
        // Jika sukses, lempar balik ke web utama beserta parameter sukses di URL
        $redirectUrl = "https://web.mastoni.site/?login_success=" . urlencode($user['telegram_id']);
        header("Location: " . $redirectUrl);
        exit;
    } else {
        $msg = "<div class='alert error'>❌ Username atau Password salah!</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mastoni Ganteng</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Sama persis dengan register.php */
        :root { --primary: #f39c12; --bg-grad: linear-gradient(135deg, #0f2027, #203a43, #2c5364); }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background: var(--bg-grad); color: #fff; min-height: 100vh; display: flex; justify-content: center; align-items: center; }
        .auth-box { background: rgba(25, 35, 45, 0.9); border: 1px solid var(--primary); padding: 40px; border-radius: 15px; width: 90%; max-width: 400px; text-align: center; box-shadow: 0 0 30px rgba(243, 156, 18, 0.2); }
        h2 { color: var(--primary); margin-bottom: 5px; }
        p.desc { color: #aaa; font-size: 0.9rem; margin-bottom: 25px; }
        .form-group { margin-bottom: 15px; text-align: left; }
        .form-group label { display: block; margin-bottom: 5px; color: #ddd; font-size: 0.9rem; }
        .form-control { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.5); color: #fff; font-size: 1rem; outline: none; }
        .form-control:focus { border-color: var(--primary); }
        .btn { display: inline-block; background: var(--primary); color: #111; padding: 12px; border-radius: 8px; font-weight: bold; width: 100%; border: none; cursor: pointer; transition: 0.3s; margin-top: 10px; }
        .btn:hover { background: #e67e22; }
        .link { color: var(--primary); text-decoration: none; font-size: 0.9rem; display: block; margin-top: 15px; }
        .alert.error { background: rgba(231, 76, 60, 0.2); border: 1px solid #e74c3c; color: #e74c3c; padding: 10px; border-radius: 5px; margin-bottom: 15px; font-size: 0.9rem;}
    </style>
</head>
<body>
    <div class="auth-box">
        <h2><i class="fas fa-sign-in-alt"></i> Member Login</h2>
        <p class="desc">Silakan masukkan akun Anda.</p>
        <?= $msg ?>
        <form method="POST" action="">
            <div class="form-group">
                <label>ID Telegram / Username</label>
                <input type="text" name="telegram_id" class="form-control" placeholder="Contoh: HookageLegend" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukkan Password" required>
            </div>
            <button type="submit" class="btn">Login & Lanjutkan <i class="fas fa-arrow-right"></i></button>
        </form>
        <a href="register.php" class="link">Belum punya akun? Daftar di sini.</a>
        <a href="https://web.mastoni.site/" class="link" style="color: #aaa;"><i class="fas fa-arrow-left"></i> Kembali ke Beranda</a>
    </div>
</body>
</html>
