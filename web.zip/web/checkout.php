<?php
$apiKey       = '';
$privateKey   = '';
$merchantCode = '';
$urlWebKita   = 'https://web.mastoni.site/';

// 1. FUNGSI CEK STATUS (DARI BOT)
if (isset($_GET['action']) && $_GET['action'] == 'check_status') {
    $reference = $_GET['reference'];
    $payload = ['reference' => $reference];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_FRESH_CONNECT  => true,
        CURLOPT_URL            => "https://tripay.co.id/api/transaction/check-status?".http_build_query($payload),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey],
    ]);

    $response = curl_exec($curl);
    curl_close($curl);
    echo $response;
    exit;
}

// 2. FUNGSI MEMBUAT TRANSAKSI
$paket_nama  = $_REQUEST['nama_paket'] ?? 'Topup Saldo Bot';
$paket_harga = (int)($_REQUEST['harga_paket'] ?? 0);
$telegram_id = $_REQUEST['telegram_id'] ?? 'Unknown';
$method      = $_REQUEST['method'] ?? 'QRIS'; 

if ($paket_harga < 2000) {
    if (isset($_REQUEST['json_response'])) {
        echo json_encode(['success' => false, 'message' => 'Minimal pembayaran Rp 2.000']);
        exit;
    } else {
        die("Minimal pembayaran adalah Rp 2.000");
    }
}

$merchantRef = 'HL-' . time();
$data = [
    'method'         => $method,
    'merchant_ref'   => $merchantRef,
    'amount'         => $paket_harga,
    'customer_name'  => $telegram_id, 
    'customer_email' => 'buyer@mastoni.site', 
    'customer_phone' => '081234567890',        
    'order_items'    => [[ 'sku' => 'VPN-01', 'name' => $paket_nama, 'price' => $paket_harga, 'quantity' => 1 ]],
    'signature'      => hash_hmac('sha256', $merchantCode.$merchantRef.$paket_harga, $privateKey)
];

$tripayEndpoint = 'https://tripay.co.id/api/transaction/create';
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_FRESH_CONNECT  => true, CURLOPT_URL => $tripayEndpoint, CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey], CURLOPT_POST => true,
    CURLOPT_POSTFIELDS     => http_build_query($data)
]);
$response = curl_exec($curl); curl_close($curl);
$result = json_decode($response);

if ($result && $result->success) { 
    // --- JIKA REQUEST DARI BOT TELEGRAM ---
    if (isset($_REQUEST['json_response'])) {
        // Ambil string QRIS (Bisa bernama qr_string atau pay_code tergantung update API TriPay)
        $qr_string = isset($result->data->qr_string) ? $result->data->qr_string : $result->data->pay_code;
        
        echo json_encode([
            'success' => true,
            'qr_data' => $qr_string,
            'amount'  => $result->data->amount,
            'ref'     => $result->data->reference
        ]);
        exit;
    }
    // --- JIKA REQUEST DARI HALAMAN WEB ---
    header("Location: " . $result->data->checkout_url); 
    exit;
} else { 
    $errMsg = $result ? $result->message : "Gagal parsing respons TriPay";
    if (isset($_REQUEST['json_response'])) {
        echo json_encode(['success' => false, 'message' => $errMsg]);
        exit;
    } else {
        echo "Error: " . $errMsg; 
        exit;
    }
}
?>